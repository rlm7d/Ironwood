Ironwood Reach battlefield-006 — compact playable/source package

Read README.md for prerequisites, startup and controls. The included Web
export still needs the authoritative Godot server; opening index.html
alone is not a complete co-op deployment. Godot 4.6.3 and matching export
templates are required and are not bundled.

This package preserves the current game source, Web export, tests, tools,
documentation and evidence reports from the full verified archive. Large
screenshots, videos, raw JSONL traces and nested proof archives have been
omitted to reduce download size. References to those files in reports
remain historical references; omission does not create new test evidence.
The full archive remains ironwood-reach-battlefield-006.zip.

Status: partial battlefield approval candidate. Exact territory rules,
public candidate hosting and human approval remain outstanding.
Full campaign development remains gated by battlefield approval.
