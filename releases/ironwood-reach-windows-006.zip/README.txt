IRONWOOD REACH — WINDOWS LOCAL BATTLEFIELD TEST 006

1. Extract the whole ZIP into a folder.
2. Double-click Start Ironwood Reach.exe. Keep its data folder beside it.
3. In the first game window click Join Builder. In the other click Join General.
4. Click Ready in both windows to start.

For Windows 10/11, 64-bit, with Microsoft Edge or Google Chrome already installed.
The matching Godot runtime is included. No Godot or Python installation is needed.
Keep the launcher open while playing. Closing it ends this unsaved local battle.
Close the two game windows afterwards; launch again for a fresh test.
The launcher can reopen either game window during the same running battle.

CONTROLS
Builder: select a home construction circle, choose a building, Confirm purchase.
General: select the barracks, choose troops, Confirm, wait for training.
Left-click selects; drag selects battalions; right-click moves.
A then left-click orders attack-move; S stops; Q/E use abilities.
Mouse wheel zooms; arrows pan. Controls in the game opens the full help.
Both players must stay connected. Disconnect pauses the battle.

SCOPE AND VERIFICATION
This is the current five-minute battlefield approval prototype. Territory
expansion, public internet co-op hosting, human approval and the campaign remain
pending. The underlying battlefield-006 source and Web export are unchanged.
The Windows launcher, HTTP transfers, server lifetime and co-op protocol were
checked under Wine in the cloud. Actual Windows-PC browser play is still untested.
Source and verification records: https://github.com/rlm7d/Ironwood

IF STARTUP FAILS
Keep the entire extracted folder together. Send the exact error message.
If port 8775 is occupied, close your previous Ironwood test and retry.
The launcher does not stop an unknown server or change firewall settings.
The development executable is unsigned.
